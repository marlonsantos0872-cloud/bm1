import './style.css'

const heroImage = '/manus-storage/async-images/mFpslo6hddnk3c7O851mjf/image-2.webp'
const logoImage = '/manus-storage/async-images/mFpslo6hddnk3c7O851mjf/image-1.webp'
const provisionalWhatsApp = '5511999999999'

const icon = (name) => {
  const icons = {
    arrow: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z"/></svg>',
    shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 5 6v5c0 4.5 2.9 8.1 7 10 4.1-1.9 7-5.5 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg>',
    wrench: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14.7 6.3 3-3a6 6 0 0 0-7.5 7.5L3.5 17.5a2.1 2.1 0 1 0 3 3l6.7-6.7a6 6 0 0 0 7.5-7.5l-3 3-3-3Z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>'
  }
  return icons[name]
}

const app = document.querySelector('#app')
app.innerHTML = `
  <header class="site-header">
    <a class="brand" href="#top" aria-label="PARIRA JUSI, início">
      <img src="${logoImage}" alt="" class="brand-mark" />
      <span class="brand-name">PARIRA <b>JUSI</b></span>
    </a>
    <nav class="desktop-nav" aria-label="Navegação principal">
      <a href="#solucoes">Soluções</a><a href="#servicos">Serviços</a><a href="#aplicacoes">Aplicações</a><a href="#contato">Contato</a>
    </nav>
    <a class="header-cta" href="#contato">Solicitar orçamento ${icon('arrow')}</a>
    <button class="mobile-toggle" aria-label="Abrir menu" aria-expanded="false">${icon('menu')}</button>
  </header>

  <main id="top">
    <section class="hero section-grid" aria-labelledby="hero-title">
      <div class="hero-content">
        <div class="eyebrow"><span class="status-dot"></span> ENERGIA EM MOVIMENTO <span class="eyebrow-line"></span></div>
        <h1 id="hero-title">Energia para o seu <em>próximo movimento.</em></h1>
        <p class="hero-copy">Soluções em geradores de energia para empresas que precisam de continuidade, segurança e suporte técnico para seguir em frente.</p>
        <div class="hero-actions"><a class="button button-primary" href="#contato">Fale com um especialista ${icon('arrow')}</a><a class="button button-ghost" href="#solucoes">Conheça as soluções <span>↓</span></a></div>
        <div class="hero-note"><span class="note-index">01</span><span>Conteúdo institucional com informações comerciais provisórias para personalização.</span></div>
      </div>
      <div class="hero-visual" style="--hero-image: url('${heroImage}')">
        <div class="visual-overlay"></div><div class="rotor-grid"></div>
        <div class="visual-label label-top">POWER SYSTEMS <span>///</span></div>
        <div class="visual-label label-bottom"><span class="pulse-line"></span> READY WHEN IT MATTERS</div>
        <div class="visual-spec"><span>STATUS</span><strong>READY</strong><small>CONTINUIDADE</small></div>
      </div>
    </section>

    <section class="signal-bar" aria-label="Benefícios">
      <div class="signal-item"><span class="signal-icon">${icon('bolt')}</span><div><small>01 / PERFORMANCE</small><strong>Operação sem pausa</strong></div></div>
      <div class="signal-item"><span class="signal-icon">${icon('shield')}</span><div><small>02 / CONFIANÇA</small><strong>Segurança para decidir</strong></div></div>
      <div class="signal-item"><span class="signal-icon">${icon('wrench')}</span><div><small>03 / SUPORTE</small><strong>Suporte que acompanha</strong></div></div>
    </section>

    <section class="section section-dark" id="solucoes" aria-labelledby="solutions-title">
      <div class="section-heading"><div><span class="section-kicker">/ 02 — SOLUÇÕES</span><h2 id="solutions-title">Potência na medida<br /><em>da sua operação.</em></h2></div><p>Da decisão ao funcionamento, a PARIRA JUSI pode ajudar a estruturar uma solução de geração de energia alinhada ao seu cenário.</p></div>
      <div class="solution-grid">
        <article class="solution-card featured"><span class="card-number">01</span><div class="card-icon">${icon('bolt')}</div><h3>Locação de geradores</h3><p>Estrutura temporária para obras, eventos, operações sazonais ou contingências. Potências e configurações a definir conforme sua necessidade.</p><a href="#contato">Explorar solução ${icon('arrow')}</a></article>
        <article class="solution-card"><span class="card-number">02</span><div class="card-icon">${icon('shield')}</div><h3>Fornecimento e venda</h3><p>Orientação para encontrar uma configuração de geração adequada ao perfil da sua operação.</p><a href="#contato">Falar com a equipe ${icon('arrow')}</a></article>
        <article class="solution-card"><span class="card-number">03</span><div class="card-icon">${icon('wrench')}</div><h3>Manutenção e suporte</h3><p>Rotinas de acompanhamento, manutenção preventiva e suporte técnico — serviços a confirmar com a equipe PARIRA JUSI.</p><a href="#contato">Conhecer serviço ${icon('arrow')}</a></article>
      </div>
    </section>

    <section class="section about-section" aria-labelledby="about-title">
      <div class="about-stamp"><div class="stamp-ring">PJ</div><span>ENERGIA<br />QUE CONECTA</span></div>
      <div class="about-copy"><span class="section-kicker">/ 03 — SOBRE A PARIRA JUSI</span><h2 id="about-title">A energia certa<br />para <em>continuar.</em></h2><p>A PARIRA JUSI nasce com um compromisso simples: ajudar negócios a manterem o que importa funcionando. Nossa proposta combina orientação próxima, visão técnica e soluções de geração de energia pensadas para a realidade de cada operação.</p><p class="muted">Esta apresentação é uma base editável. História, localização, equipe e diferenciais oficiais podem ser incluídos após o envio das informações da empresa.</p><a class="text-link" href="#contato">Vamos conversar ${icon('arrow')}</a></div>
      <div class="about-metric"><span>FOCO</span><strong>PJ</strong><small>NO SEU CENÁRIO</small></div>
    </section>

    <section class="section section-light" id="servicos" aria-labelledby="services-title">
      <div class="section-heading"><div><span class="section-kicker">/ 04 — COMO TRABALHAMOS</span><h2 id="services-title">Do primeiro contato<br />à <em>energia entregue.</em></h2></div><p>Um fluxo claro para transformar uma necessidade de energia em uma próxima decisão segura.</p></div>
      <div class="process-grid"><div class="process-step"><span>01</span><h3>Entender</h3><p>Mapeamos a demanda, o prazo e o contexto da sua operação.</p></div><div class="process-step"><span>02</span><h3>Dimensionar</h3><p>Indicamos capacidades e configurações para o cenário informado.</p></div><div class="process-step"><span>03</span><h3>Instalar</h3><p>Coordenamos a entrega e a estrutura necessária — conforme a contratação.</p></div><div class="process-step"><span>04</span><h3>Acompanhar</h3><p>Seguimos próximos para apoiar a continuidade do seu negócio.</p></div></div>
    </section>

    <section class="section applications" id="aplicacoes" aria-labelledby="applications-title"><div class="section-heading"><div><span class="section-kicker">/ 05 — APLICAÇÕES</span><h2 id="applications-title">Onde a energia<br /><em>faz diferença.</em></h2></div><p>Exemplos de cenários que podem contar com soluções de geração. Ajuste estes segmentos conforme a atuação real da PARIRA JUSI.</p></div><div class="application-list"><a href="#contato"><span>01</span><strong>Obras e construção</strong><small>Energia para cada etapa</small>${icon('arrow')}</a><a href="#contato"><span>02</span><strong>Indústria e operações</strong><small>Continuidade produtiva</small>${icon('arrow')}</a><a href="#contato"><span>03</span><strong>Eventos e estruturas</strong><small>Experiências sem interrupção</small>${icon('arrow')}</a><a href="#contato"><span>04</span><strong>Agronegócio</strong><small>Potência onde ela é necessária</small>${icon('arrow')}</a></div></section>

    <section class="contact-section" id="contato" aria-labelledby="contact-title"><div class="contact-intro"><span class="section-kicker">/ 06 — FALE COM A GENTE</span><h2 id="contact-title">Vamos manter<br /><em>seu negócio ligado.</em></h2><p>Conte um pouco do que você precisa. A equipe PARIRA JUSI retorna para entender o cenário e orientar os próximos passos.</p><div class="contact-details"><div><small>WHATSAPP / EXEMPLO EDITÁVEL</small><strong>(11) 99999-9999</strong></div><div><small>E-MAIL / EXEMPLO EDITÁVEL</small><strong>contato@parirajusi.com.br</strong></div><div><small>ATENDIMENTO / A CONFIRMAR</small><strong>Sua cidade — UF</strong></div></div></div><form class="quote-form"><div class="form-row"><label>Seu nome<input name="name" type="text" placeholder="Como podemos chamar você?" required /></label><label>Empresa<input name="company" type="text" placeholder="Nome da empresa" /></label></div><div class="form-row"><label>WhatsApp<input name="phone" type="tel" placeholder="(00) 00000-0000" required /></label><label>Cidade / UF<input name="city" type="text" placeholder="Onde será a operação?" /></label></div><label>O que você precisa?<textarea name="message" rows="4" placeholder="Conte sobre a potência, prazo ou cenário da sua operação..."></textarea></label><button class="button button-primary" type="submit">Solicitar orçamento ${icon('arrow')}</button><p class="form-status" role="status" aria-live="polite"></p><small class="form-disclaimer">Ao enviar, você inicia uma conversa comercial. Os dados de contato exibidos nesta versão são exemplos editáveis.</small></form></section>
  </main>
  <footer class="site-footer"><a class="brand" href="#top"><img src="${logoImage}" alt="" class="brand-mark" /><span class="brand-name">PARIRA <b>JUSI</b></span></a><div class="footer-legal"><strong>00.182.526/0001-30</strong><span>00.182.526 JOSE FRANCISCO MARTINS PARREIRA</span><span>Constituída em 25/08/1994</span><small>Todos os direitos reservados.</small></div><a href="#top">Voltar ao topo ↑</a></footer>
`

const mobileToggle = document.querySelector('.mobile-toggle')
const nav = document.querySelector('.desktop-nav')
mobileToggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open')
  mobileToggle.setAttribute('aria-expanded', String(isOpen))
})
nav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => nav.classList.remove('open')))

document.querySelector('.quote-form')?.addEventListener('submit', (event) => {
  event.preventDefault()
  const form = event.currentTarget
  const name = form.elements.name.value.trim()
  const message = form.querySelector('.form-status')
  message.textContent = `Obrigado, ${name || 'por entrar em contato'}. Sua solicitação foi registrada nesta demonstração. Substitua o número provisório para ativar o WhatsApp comercial.`
  message.classList.add('visible')
  form.reset()
  const wa = `https://wa.me/${provisionalWhatsApp}?text=${encodeURIComponent('Olá, PARIRA JUSI! Gostaria de solicitar um orçamento.')}`
  setTimeout(() => { message.innerHTML += ` <a href="${wa}" target="_blank" rel="noreferrer">Abrir WhatsApp de exemplo →</a>` }, 100)
})
